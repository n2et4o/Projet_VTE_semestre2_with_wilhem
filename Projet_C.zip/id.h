//
// Created by 20220848 on 18/04/2023.
//

#ifndef PROJET_VTE_SEMESTRE2_ID_H
#define PROJET_VTE_SEMESTRE2_ID_H

extern unsigned int global_id;
unsigned int get_next_id();


#endif //PROJET_VTE_SEMESTRE2_ID_H
