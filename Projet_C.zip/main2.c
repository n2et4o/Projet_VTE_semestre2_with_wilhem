//
// Created by 20220848 on 22/04/2023.
//

#include <stdio.h>
#include "point.h"
#include "figures.h"
#include "Shape.h"
/*
int main() {
    int x ,y ,len;

    create_circle_shape( 76, 12, 3);
    //choisir_coordonnees(&x, &y);
    //Point * p1 = create_point (x, y);
      Point p1 = { 12 ,12};
     //choisir_coordonnees(&x, &y);
     //Point * p2 = create_point (x,y);

     int list[6] = {1 , 2,3, 45, 5, 6};
    create_polygon_shape(list,3);


     /*Line * l = create_line (p1 ,p2);
     print_line (l);
     delete_line(l);
     delete_point(p1);
     delete_point(p2);
     printf("\n"); */
    /*
    printf("choississez une longueur :");
    scanf("%d",&len);

    Square* carre = create_square(&p1,len);
    print_square (carre);
    delete_square(carre);

    Square* carree = create_square(p2,len);
    print_square (carree);

    int largeur ;
    printf("Choississez une largeur :");
    scanf("%d",&largeur);

    Rectangle * rect = create_rectangle(p2, largeur  , len);
    print_rectangle(rect);
    delete_rectangle(rect);

    Rectangle * recta = create_rectangle(&p1, largeur  , len);
    print_rectangle(recta);
    delete_rectangle(recta);

    int rad;
    printf("Choissisez un rayon :");
    scanf("%d",&rad);
    Circle * cercle = create_circle(&p1,rad);
    print_circle(cercle);
    delete_circle(cercle);

    Circle * cercle2 = create_circle(p2,rad);
    print_circle(cercle2);
    delete_circle(cercle2);  */
    /*
    int n ;
    printf("Choississez le nombres de sommets de votre polygone :");
    scanf("%d",&n);
    Polygon * polygone = create_polygon(n);
    print_polygon(polygone);
    delete_polygon( polygone);

    int radus = 3;
    Point p ;




    return 0;
}

*/